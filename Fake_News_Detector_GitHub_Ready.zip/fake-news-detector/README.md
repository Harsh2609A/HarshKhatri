# Fake News & Misinformation Detection System

Career Point University · B.Tech CSE (AI & ML) · Academic Year 2026–27

A responsive Flask web app for article/headline screening. The project structure follows the uploaded synopsis: text input, TF-IDF feature extraction, a classical ML classifier, prediction API, and a browser interface.

## Important model note
The app deliberately does **not** pretend to detect fake news before a labelled dataset has been trained. Until `models/fake_news_pipeline.pkl` exists, the API returns **Unverified** and explains that training is required. After training, it returns the model's Real/Fake estimate and probability. This is a screening aid, not proof or independent fact-checking.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Train the model
1. Obtain a labelled English news dataset you are permitted to use.
2. Place it at `data/news.csv`.
3. Include `label` and either `text` or `title` columns. If both `title` and `text` exist, they are combined. Labels may be `Real`/`Fake` or `1`/`0` (1=Real, 0=Fake).
4. Run:
```bash
python train_model.py
```
5. Restart the Flask app. The saved pipeline is loaded automatically.

The training script prints accuracy, precision, recall and F1-score via `classification_report`. Record your actual test results in your project report; do not claim unmeasured accuracy.

## Publish with GitHub + Render
GitHub Pages hosts static sites and cannot run this Flask backend. Use GitHub for source control and Render for the public Flask app.

1. Create a new **public** GitHub repository named `fake-news-detector`.
2. Upload/push all files from this folder to the repository.
3. On Render, choose **New → Web Service**, connect that GitHub repository, and keep the commands from `render.yaml` (or use build `pip install -r requirements.txt`, start `gunicorn app:app`).
4. After deployment, Render provides a public `https://...onrender.com` URL.

For genuine predictions, train the model and deploy the model file as part of the service build or use a persistent release artifact. Do not commit a large or untrusted pickle file to a public repository. Only load model files you created and trust.

## Project modules
- Web interface: `templates/index.html`, `static/style.css`, `static/app.js`
- Prediction API: `app.py`
- Model training/evaluation: `train_model.py`
- Deployment: `Procfile`, `render.yaml`

## Limitations
English text only; no live social-media feed, image/video/audio deepfake analysis, or verified-claims database. Short or misleading text can fool classifiers. Always verify important claims with reliable sources.
