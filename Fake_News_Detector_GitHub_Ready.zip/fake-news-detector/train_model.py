"""Train the TF-IDF + Logistic Regression baseline.
Expected CSV columns: text,label OR title,text,label.
Labels should be Real/Fake (case-insensitive) or 1/0.
"""
import os
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

DATA_PATH = os.environ.get("NEWS_DATASET", "data/news.csv")
OUT_PATH = "models/fake_news_pipeline.pkl"

def main():
    if not os.path.exists(DATA_PATH):
        raise SystemExit(f"Dataset not found: {DATA_PATH}. Add a labelled CSV first.")
    df = pd.read_csv(DATA_PATH)
    if "label" not in df.columns:
        raise SystemExit("CSV must contain a 'label' column.")
    text_col = "text" if "text" in df.columns else None
    if text_col is None and "title" in df.columns:
        df["text"] = df["title"].fillna("")
        text_col = "text"
    if text_col is None:
        raise SystemExit("CSV must contain 'text' or 'title' column.")
    if "title" in df.columns and "text" in df.columns:
        df["combined"] = df["title"].fillna("").astype(str) + " " + df["text"].fillna("").astype(str)
        text_col = "combined"
    df = df[[text_col, "label"]].dropna()
    df[text_col] = df[text_col].astype(str).str.strip()
    df = df[df[text_col].str.len() > 0]
    df["label"] = df["label"].astype(str).str.strip().str.lower().replace({
        "0": "fake", "1": "real", "false": "fake", "true": "real"
    })
    if df["label"].nunique() < 2:
        raise SystemExit("Dataset must contain at least two label classes (Real and Fake).")

    X_train, X_test, y_train, y_test = train_test_split(
        df[text_col], df["label"], test_size=0.2, random_state=42, stratify=df["label"]
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer(stop_words="english", max_df=0.9, min_df=2, ngram_range=(1, 2))),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print("Accuracy:", round(accuracy_score(y_test, predictions), 4))
    print(classification_report(y_test, predictions))
    os.makedirs("models", exist_ok=True)
    with open(OUT_PATH, "wb") as f:
        pickle.dump(model, f)
    print(f"Saved trained model to {OUT_PATH}")

if __name__ == "__main__":
    main()
