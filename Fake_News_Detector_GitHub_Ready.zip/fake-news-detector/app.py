import os
import re
import pickle
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
MODEL_PATH = os.path.join("models", "fake_news_pipeline.pkl")
pipeline = None

def load_model():
    global pipeline
    try:
        with open(MODEL_PATH, "rb") as f:
            pipeline = pickle.load(f)
    except (FileNotFoundError, EOFError, pickle.UnpicklingError):
        pipeline = None

load_model()

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/status")
def status():
    return jsonify({"model_ready": pipeline is not None})

@app.post("/api/predict")
def predict():
    global pipeline
    payload = request.get_json(silent=True) or {}
    article = re.sub(r"\s+", " ", str(payload.get("text", ""))).strip()
    if len(article) < 30:
        return jsonify({"error": "Please enter at least 30 characters for a useful analysis."}), 400
    if len(article) > 20000:
        return jsonify({"error": "Please keep the text under 20,000 characters."}), 400

    if pipeline is None:
        return jsonify({
            "mode": "demo",
            "label": "Unverified",
            "confidence": None,
            "message": "The trained ML model is not installed yet. This public demo is ready for model training; no real/fake verdict is being invented.",
            "signals": ["Model training required", "Prediction is disabled until a labelled dataset is supplied"]
        })

    probabilities = pipeline.predict_proba([article])[0]
    classes = list(pipeline.classes_)
    best_idx = int(probabilities.argmax())
    predicted = str(classes[best_idx]).strip().lower()
    label = "Real" if predicted in {"real", "1", "true"} else "Fake"
    confidence = round(float(probabilities[best_idx]) * 100, 1)
    return jsonify({
        "mode": "model",
        "label": label,
        "confidence": confidence,
        "message": "This is a machine-learning estimate based on the model's training data, not independent fact-checking.",
        "signals": ["TF-IDF text features", "Trained classification pipeline"]
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
