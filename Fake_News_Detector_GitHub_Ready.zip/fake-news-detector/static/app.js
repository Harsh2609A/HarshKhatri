const textArea = document.getElementById("newsText");
const charCount = document.getElementById("charCount");
const analyseBtn = document.getElementById("analyseBtn");
const emptyState = document.getElementById("emptyState");
const loadingState = document.getElementById("loadingState");
const resultState = document.getElementById("resultState");

const samples = {
  real: "The city council on Tuesday approved a budget for road repairs after a public meeting. Officials said the work will begin in January and published the project details on the municipal website. The proposal passed with 18 votes in favour and 3 against.",
  fake: "SHOCKING! Scientists CONFIRM that drinking a secret purple liquid makes people invisible overnight! Officials are hiding the truth and every citizen must try it immediately before the government deletes this message!"
};

textArea.addEventListener("input", () => {
  charCount.textContent = `${textArea.value.length.toLocaleString()} / 20,000`;
});
document.getElementById("clearBtn").addEventListener("click", () => {
  textArea.value = "";
  charCount.textContent = "0 / 20,000";
  textArea.focus();
});
document.querySelectorAll(".sample-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    textArea.value = samples[btn.dataset.sample];
    charCount.textContent = `${textArea.value.length} / 20,000`;
    textArea.focus();
  });
});
document.getElementById("againBtn").addEventListener("click", () => {
  resultState.classList.add("hidden");
  emptyState.classList.remove("hidden");
  textArea.focus();
});

analyseBtn.addEventListener("click", async () => {
  const text = textArea.value.trim();
  if (text.length < 30) {
    alert("Please enter at least 30 characters.");
    textArea.focus();
    return;
  }
  emptyState.classList.add("hidden");
  resultState.classList.add("hidden");
  loadingState.classList.remove("hidden");
  analyseBtn.disabled = true;
  try {
    const response = await fetch("/api/predict", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({text})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not analyse this text.");
    showResult(data);
  } catch (error) {
    loadingState.classList.add("hidden");
    emptyState.classList.remove("hidden");
    alert(error.message || "Connection error. Please try again.");
  } finally {
    analyseBtn.disabled = false;
  }
});

function showResult(data) {
  loadingState.classList.add("hidden");
  resultState.classList.remove("hidden");
  const badge = document.getElementById("resultBadge");
  const title = document.getElementById("resultTitle");
  const confidence = document.getElementById("confidenceBlock");
  badge.className = "result-badge";
  if (data.label === "Fake") badge.classList.add("fake");
  if (data.label === "Real") badge.classList.add("real");
  badge.textContent = data.label === "Unverified" ? "UNVERIFIED" : `${data.label.toUpperCase()} NEWS`;
  title.textContent = data.label === "Unverified" ? "Model training required" : `Model estimate: ${data.label}`;
  document.getElementById("resultMessage").textContent = data.message;
  if (data.confidence !== null && data.confidence !== undefined) {
    confidence.classList.remove("hidden");
    document.getElementById("confidenceValue").textContent = `${data.confidence}%`;
    document.getElementById("confidenceMeter").style.width = `${data.confidence}%`;
  } else {
    confidence.classList.add("hidden");
  }
  const list = document.getElementById("signalsList");
  list.replaceChildren();
  (data.signals || []).forEach(signal => {
    const li = document.createElement("li");
    li.textContent = signal;
    list.appendChild(li);
  });
}
